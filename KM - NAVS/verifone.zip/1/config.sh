vlr -c 'config.txt' 'config.$$$'

